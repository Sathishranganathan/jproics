import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.*;
import java.text.*;
import java.io.*;
import java.awt.PrintJob.*;		//For Printing the Records.
import javax.swing.plaf.metal.*;	//For Change Look & Feel and Themes Options.

public class LibrarySystem extends JFrame implements ActionListener, ItemListener {

	//Main Place on Form where All Child Forms will Shown.

	private JDesktopPane desktop = new JDesktopPane ();

	//For Program's MenuBar.

	private JMenuBar bar;

	//All the Main Menu of the Program.

	private JMenu mnuFile, mnuEdit, mnuView, mnuOpt, mnuWin, mnuHelp;

	//All the MenuItem Options of Program.

	private JMenuItem newBook, newMember, printBook, printMember, printIssueBook, end;	//File Menu Options.
	private	JMenuItem issueBook, returnBook, delBook, delMember, findBook, findMember;	//Edit Menu Options.
	private	JMenuItem viewAllBook, viewAllMember, viewIssueBook;				//View Menu Options.
	private	JMenuItem change, style, theme;							//Option Menu Options.
	private JMenuItem changePassword, makeUser, close, closeAll;				//Window Menu Options.
	private	JMenuItem content, keyHelp, about;						//Help Menu Options.

	//PopupMenu of Program.

	private JPopupMenu popMenu = new JPopupMenu ();

	//MenuItems for PopupMenu of the Program.

	private JMenuItem book, member, print, issue, bookReturn, find, view;

	//For Program's ToolBar.

	private	JToolBar toolBar;

	//For ToolBar's Button.

	private	JButton btnNewBook, btnNewMember, btnIssue, btnReturn, btnPrintIssue, btnDelBook, 
				btnDelMember, btnFindBook, btnFindMember, btnChange, btnHelp, btnKey;

	//Panel For Main Form StatusBar where Program's Name & Welcome Message Display.

	private JPanel statusBar = new JPanel ();

	//Labels for Displaying Program's Name & saying Welcome to User on StatusBar.

	private JLabel lbStatus;	//For Program's Status.
	private JLabel lbWelcome;	//For Welcome Message.

	//Getting the Current System Date.

	private java.util.Date currDate = new java.util.Date ();					//Creating Object.
	private SimpleDateFormat sdf = new SimpleDateFormat ("dd MMMM yyyy", Locale.getDefault());	//Changing Format.
	private String d = sdf.format (currDate);							//Storing Date.

	//Setting the Look & Feel Menu.

	private String strings[] = {"1. Metal", "2. Motif", "3. Windows"};
	private UIManager.LookAndFeelInfo looks[] = UIManager.getInstalledLookAndFeels ();
	private ButtonGroup group = new ButtonGroup ();
	private JRadioButtonMenuItem radio[] = new JRadioButtonMenuItem[strings.length];

	private Connection con;		//For Creating the Connection Between Program & Database.
	private Statement st;		//For Getting the Tables From Database.

	private String userName;	//For Getting the Current User's Name.

	//Constructor of The LibrarySystem Program to Iniatilize all Variables of Program.

	public LibrarySystem (String user, Connection conn) {

		//Setting Program's Title.

		super ("Muhammad Wasif's LibrarySystem.");

		//Setting the Main Window of Program.

		setIconImage (getToolkit().getImage ("Images/Home.gif"));	//Setting the Program's Icon.
		setSize (700, 550);						//Setting Main Window Size.

		//Setting the Location of Program on User's Computer Screen By Getting the Screen's Height & Width.

		setLocation((Toolkit.getDefaultToolkit().getScreenSize().width  - getWidth()) / 2,
			(Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2);

		//Closing Code of Main Window.

		addWindowListener (new WindowAdapter () {		//Attaching the WindowListener to Program.
			public void windowClosing (WindowEvent we) {	//Overriding the windowClosing Function.
				quitApp ();				//Call the Function to Perform the Closing Action.
			}
		}
		);

		//For Making the Dragging Speed of Internal Frames Faster.

		desktop.putClientProperty ("JDesktopPane.dragMode", "outline");

		//Creating the MenuBar For Displaying All the Menus of Program.

		bar = new JMenuBar ();		//Creating the MenuBar Object.
		setJMenuBar (bar);		//Setting Main Window MenuBar.

		//Creating the Menus of Program & Assigning the Key too to Open them.

		mnuFile = new JMenu ("File");
		mnuFile.setMnemonic ((int)'F');
		mnuEdit = new JMenu ("Edit");
		mnuEdit.setMnemonic ((int)'E');
		mnuView = new JMenu ("View");
		mnuView.setMnemonic ((int)'V');
		mnuOpt = new JMenu ("Options");
		mnuOpt.setMnemonic ((int)'O');
		mnuWin = new JMenu ("Window");
		mnuWin.setMnemonic ((int)'W');
		mnuHelp = new JMenu ("Help");
		mnuHelp.setMnemonic ((int)'H');

		//Creating All the MenuItems of Program.

		//MenuItems for FileMenu.

		newBook = new JMenuItem ("Add New Book", new ImageIcon ("Images/Open.gif"));
		newBook.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_N, Event.CTRL_MASK));
		newBook.setMnemonic ((int)'N');
		newBook.addActionListener (this);
		newMember = new JMenuItem ("Add New Member", new ImageIcon ("Images/New.gif"));
		newMember.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_M, Event.CTRL_MASK));
		newMember.setMnemonic ((int)'M');
		newMember.addActionListener (this);
		printBook = new JMenuItem ("Print Book Record", new ImageIcon ("Images/Cut.gif"));
		printBook.setMnemonic ((int)'R');
		printBook.addActionListener (this);
		printMember = new JMenuItem ("Print Member Record", new ImageIcon ("Images/add.gif"));
		printMember.setMnemonic ((int)'T');
		printMember.addActionListener (this);
		printIssueBook = new JMenuItem ("Print Issue Book Record", new ImageIcon ("Images/copy.gif"));
		printIssueBook.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_P, Event.CTRL_MASK));
		printIssueBook.setMnemonic ((int)'P');
		printIssueBook.addActionListener (this);
		end = new JMenuItem ("Quit LibrarySystem ?", new ImageIcon ("Images/export.gif"));
		end.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_Q, Event.CTRL_MASK));
		end.setMnemonic ((int)'Q');	
		end.addActionListener (this);

		//MenuItems for EditMenu.

		issueBook = new JMenuItem ("Issue Book");
		issueBook.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_I, Event.CTRL_MASK));
		issueBook.setMnemonic ((int)'I');
		issueBook.addActionListener (this);
		returnBook = new JMenuItem ("Return Book");
		returnBook.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_R, Event.CTRL_MASK));
		returnBook.setMnemonic ((int)'R');	
		returnBook.addActionListener (this);
		delBook = new JMenuItem ("Delete Book", new ImageIcon ("Images/Delete.gif"));
		delBook.setMnemonic ((int)'D');
		delBook.addActionListener (this);
		delMember = new JMenuItem ("Delete Member");
		delMember.setMnemonic ((int)'D');
		delMember.addActionListener (this);
		findBook = new JMenuItem ("Search Book");
		findBook.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_F, Event.CTRL_MASK));
		findBook.setMnemonic ((int)'F');
		findBook.addActionListener (this);
		findMember = new JMenuItem ("Search Member", new ImageIcon ("Images/find.gif"));
		findMember.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_S, Event.CTRL_MASK));
		findMember.setMnemonic ((int)'S');	
		findMember.addActionListener (this);

		//MenuItems for ViewMenu.

		viewAllBook = new JMenuItem ("View All Books", new ImageIcon ("Images/Fruit.gif"));
		viewAllBook.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_A, Event.CTRL_MASK));
		viewAllBook.setMnemonic ((int)'A');	
		viewAllBook.addActionListener (this);
		viewAllMember = new JMenuItem ("View All Members", new ImageIcon ("Images/Refresh.gif"));
		viewAllMember.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_V, Event.CTRL_MASK));
		viewAllMember.setMnemonic ((int)'V');	
		viewAllMember.addActionListener (this);
		viewIssueBook = new JMenuItem ("View Issued Books");
		viewIssueBook.setMnemonic ((int)'I');	
		viewIssueBook.addActionListener (this);

		//MenuItems for OptionMenu.

		change = new JMenuItem ("Change Background Color");
		change.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_B, Event.CTRL_MASK));
		change.setMnemonic ((int)'C');
		change.addActionListener (this);

		//StyleMenu For Changing the Program's Layout.

		style = new JMenu ("Change Layout Style");
		style.setMnemonic ((int)'S');
		for( int i = 0; i < radio.length ; i++ ) {			//Creating the subMenus of Style Menu.
			radio[i] = new JRadioButtonMenuItem (strings[i]);	//Build an Array of Layouts to Apply.
			radio[i].setSelected (true);
			radio[i].addItemListener (this);			//Setting their Actions.
			group.add (radio[i]);					//Making them Grouped.
			style.add (radio[i]);					//Adding to Style MenuOption.
		}

		//SubMenu of ThemeMenu For Applying different Themes to Program By Building an Array of Themes to Apply.
		
		//Attaching the PropertyChangeListener to Program For Applying the Themes.

		UIManager.addPropertyChangeListener (new UISwitchListener ((JComponent)getRootPane()));

		MetalTheme[] themes = { new DefaultMetalTheme (), new BlueTheme (), new BrownTheme (), new GreenTheme (), 
				new ChocTheme (), new OrangeTheme (), new PinkTheme (), new RedTheme (), 
				new WaterTheme (), new YellowTheme () };	//Buliding the Array of Themes Objects.
		theme = new MetalThemeMenu ("Apply Theme", themes);		//Putting the Themes in ThemeMenu.
		theme.setMnemonic ((int)'T');

		//MenuItems for WindowMenu.

		changePassword = new JMenuItem ("Change Your Password");
		changePassword.setMnemonic ((int)'P');
		changePassword.addActionListener (this);
		makeUser = new JMenuItem ("Create New User");
		makeUser.setMnemonic ((int)'N');
		makeUser.addActionListener (this);
		close = new JMenuItem ("Close Active Window");
		close.setMnemonic ((int)'C');
		close.addActionListener (this);
		closeAll = new JMenuItem ("Close All Windows...");
		closeAll.setMnemonic ((int)'A');
		closeAll.addActionListener (this);

		//MenuItems for HelpMenu.

		content = new JMenuItem ("Help Contents", new ImageIcon ("Images/Glass.gif"));
		content.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_H, Event.CTRL_MASK));
		content.setMnemonic ((int)'H');
		content.addActionListener (this);
		keyHelp = new JMenuItem ("Shortcut Keys...");
		keyHelp.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_K, Event.CTRL_MASK));
		keyHelp.setMnemonic ((int)'K');
		keyHelp.addActionListener (this);
		about = new JMenuItem ("About LibrarySystem", new ImageIcon ("Images/Windows.gif"));
		about.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_L, Event.CTRL_MASK));
		about.setMnemonic ((int)'L');
		about.addActionListener (this);

		//Adding All MenuItems to their Menu.
	
		//File Menu Items.
		mnuFile.add (newBook);
		mnuFile.add (newMember);
		mnuFile.addSeparator ();
		mnuFile.add (printBook);
		mnuFile.add (printMember);
		mnuFile.add (printIssueBook);
		mnuFile.addSeparator ();
		mnuFile.add (end);

		//Edit Menu Items.
		mnuEdit.add (issueBook);
		mnuEdit.add (returnBook);
		mnuEdit.addSeparator ();
		mnuEdit.add (delBook);
		mnuEdit.add (delMember);
		mnuEdit.addSeparator ();
		mnuEdit.add (findBook);
		mnuEdit.add (findMember);

		//View Menu Items.
		mnuView.add (viewAllBook);
		mnuView.addSeparator ();
		mnuView.add (viewAllMember);
		mnuView.addSeparator ();
		mnuView.add (viewIssueBook);

		//Options Menu Items.
		mnuOpt.add (change);
		mnuOpt.addSeparator ();
		mnuOpt.add (style);
		mnuOpt.addSeparator ();
		mnuOpt.add (theme);

		//Window Menu Items.
		mnuWin.add (changePassword);
		mnuWin.add (makeUser);
		mnuWin.addSeparator ();
		mnuWin.add (close);
		mnuWin.add (closeAll);

		//Help Menu Items.
		mnuHelp.add (content);
		mnuHelp.addSeparator ();
		mnuHelp.add (keyHelp);
		mnuHelp.addSeparator ();
		mnuHelp.add (about);

		//Adding All Menus to MenuBar.

		bar.add (mnuFile);
		bar.add (mnuEdit);
		bar.add (mnuView);
		bar.add (mnuOpt);
		bar.add (mnuWin);
		bar.add (mnuHelp);

		//MenuItems for PopupMenu.

		book = new JMenuItem ("Add New Book", new ImageIcon ("Images/Open.gif"));
		book.addActionListener (this);
		member = new JMenuItem ("Add New Member", new ImageIcon ("Images/New.gif"));
		member.addActionListener (this);
		print = new JMenuItem ("Print Book Record", new ImageIcon ("Images/Cut.gif"));
		print.addActionListener (this);
		issue = new JMenuItem ("Issue Book");
		issue.addActionListener (this);
		bookReturn = new JMenuItem ("Return Book");
		bookReturn.addActionListener (this);
		find = new JMenuItem ("Search Book", new ImageIcon ("Images/Find.gif"));
		find.addActionListener (this);
		view = new JMenuItem ("View All Members", new ImageIcon ("Images/refresh.gif"));
		view.addActionListener (this);

		//Adding MenuItems to PopupMenu.

		popMenu.add (book);
		popMenu.add (member);
		popMenu.add (print);
		popMenu.add (issue);
		popMenu.add (bookReturn);
		popMenu.add (find);
		popMenu.add (view);

		//Following Procedure display the PopupMenu of Program Whenever User Right Click on Program By Mouse.

		addMouseListener (new MouseAdapter () {
			public void mousePressed (MouseEvent me) { checkMouseTrigger (me); }
			public void mouseReleased (MouseEvent me) { checkMouseTrigger (me); }
			private void checkMouseTrigger (MouseEvent me) {
				if (me.isPopupTrigger ())
					popMenu.show (me.getComponent (), me.getX (), me.getY ());
			}
		}
		);
		
		//Creating the ToolBar's Buttons of Program.

		btnNewBook = new JButton (new ImageIcon ("Images/NotePad.gif"));
		btnNewBook.setToolTipText ("Add New Book");
		btnNewBook.addActionListener (this);
		btnNewMember = new JButton (new ImageIcon ("Images/Info.gif"));
		btnNewMember.setToolTipText ("Add New Member");
		btnNewMember.addActionListener (this);
		btnIssue = new JButton (new ImageIcon ("Images/Film.gif"));
		btnIssue.setToolTipText ("Issue Book");
		btnIssue.addActionListener (this);
		btnReturn = new JButton (new ImageIcon ("Images/Backup.gif"));
		btnReturn.setToolTipText ("Return Book");
		btnReturn.addActionListener (this);
		btnPrintIssue = new JButton (new ImageIcon ("Images/Hp.gif"));
		btnPrintIssue.setToolTipText ("Print Issue Book");
		btnPrintIssue.addActionListener (this);
		btnDelBook = new JButton (new ImageIcon ("Images/Recycle.gif"));
		btnDelBook.setToolTipText ("Delete Book");
		btnDelBook.addActionListener (this);
		btnDelMember = new JButton (new ImageIcon ("Images/Basket.gif"));
		btnDelMember.setToolTipText ("Delete Member");
		btnDelMember.addActionListener (this);
		btnFindBook = new JButton (new ImageIcon ("Images/Mirror.gif"));
		btnFindBook.setToolTipText ("Search Book");
		btnFindBook.addActionListener (this);
		btnFindMember = new JButton (new ImageIcon ("Images/Search.gif"));
		btnFindMember.setToolTipText ("Search Member");
		btnFindMember.addActionListener (this);
		btnChange = new JButton (new ImageIcon ("Images/Key.gif"));
		btnChange.setToolTipText ("Change Your Password");
		btnChange.addActionListener (this);
		btnHelp = new JButton (new ImageIcon ("Images/Help.gif"));
		btnHelp.setToolTipText ("Help on LibrarySystem");
		btnHelp.addActionListener (this);
		btnKey = new JButton (new ImageIcon ("Images/Keys.gif"));
		btnKey.setToolTipText ("Shortcut Keys of LibrarySystem");
		btnKey.addActionListener (this);

		//Creating the ToolBar of Program.

		toolBar = new JToolBar ();
		toolBar.add (btnNewBook);
		toolBar.add (btnNewMember);
		toolBar.addSeparator ();
		toolBar.add (btnIssue);
		toolBar.add (btnReturn);
		toolBar.addSeparator ();
		toolBar.add (btnPrintIssue);
		toolBar.addSeparator ();
		toolBar.add (btnDelBook);
		toolBar.add (btnDelMember);
		toolBar.addSeparator ();
		toolBar.add (btnFindBook);
		toolBar.add (btnFindMember);
		toolBar.addSeparator ();
		toolBar.add (btnChange);
		toolBar.addSeparator ();
		toolBar.add (btnHelp);
		toolBar.add (btnKey);

		//Getting the Current User.

		userName = user;

		//If Current User not Administrator of Program.

		if (!(userName.equals ("Admin"))) {
			newBook.setEnabled (false);
			book.setEnabled (false);
			btnNewBook.setEnabled (false);
			newMember.setEnabled (false);
			member.setEnabled (false);
			btnNewMember.setEnabled (false);
			issueBook.setEnabled (false);
			issue.setEnabled (false);
			btnIssue.setEnabled (false);
			makeUser.setEnabled (false);
		}

		//Creating the StatusBar of Program.

		lbStatus = new JLabel (" " + "Muhammad Wasif's LibrarySystem.", Label.LEFT);
		lbStatus.setForeground (Color.black);
		lbStatus.setToolTipText ("Program's Title");
		lbWelcome = new JLabel ("Welcome " + userName + " Today is " + d + " ", JLabel.RIGHT);
		lbWelcome.setForeground (Color.black);
		lbWelcome.setToolTipText ("Welcome User : System Current Date");
		statusBar.setLayout (new BorderLayout());
		statusBar.add (lbStatus, BorderLayout.WEST);
		statusBar.add (lbWelcome, BorderLayout.EAST);

		//Setting the Contents of Programs.

		getContentPane().add (toolBar, BorderLayout.NORTH);
		getContentPane().add (desktop, BorderLayout.CENTER);
		getContentPane().add (statusBar, BorderLayout.SOUTH);

		//Getting the Database.

		con = conn;

		//Showing The Main Form of Application.

		setVisible (true);

	}

	//Function For Performing different Actions By Menus of Program.

	public void actionPerformed (ActionEvent ae) {
	
		Object obj = ae.getSource();

		if (obj == newBook || obj == book || obj == btnNewBook) {

			boolean b = openChildWindow ("Add New Book");
			if (b == false) {
				AddBook adBook = new AddBook (con);
				desktop.add (adBook);			//Adding Child Window to DesktopPane.
				adBook.show ();				//Showing the Child Window.
			}

		}
		else if (obj == newMember || obj == member || obj == btnNewMember) {

			boolean b = openChildWindow ("Add New Member");
			if (b == false) {
				AddMember adMember = new AddMember (con);
				desktop.add (adMember);
				adMember.show ();
			}

		}
		else if (obj == printBook || obj == print) {

			getBookId ();

		}
		else if (obj == printMember) {

			getMemberId ();

		}
		else if (obj == printIssueBook || obj == btnPrintIssue) {

			getIssueBook ();

		}
		else if (obj == end) {

			quitApp ();	//Calling the Function to Quit the Program.

		}
		else if (obj == issueBook || obj == issue || obj == btnIssue) {

			boolean b = openChildWindow ("Issue Book");
			if (b == false) {
				IssueBook isBook = new IssueBook (con);
				desktop.add (isBook);
				isBook.show ();
			}

		}
		else if (obj == returnBook || obj == bookReturn || obj == btnReturn) {

			boolean b = openChildWindow ("Return Book");
			if (b == false) {
				ReturnBook rtBook = new ReturnBook (con);
				desktop.add (rtBook);
				rtBook.show ();
			}

		}
		else if (obj == delBook || obj == btnDelBook) {

			boolean b = openChildWindow ("Delete Book");
			if (b == false) {
				DeleteBook dlBook = new DeleteBook (con);
				desktop.add (dlBook);
				dlBook.show ();
			}

		}
		else if (obj == delMember || obj == btnDelMember) {

			boolean b = openChildWindow ("Delete Member");
			if (b == false) {
				DeleteMember dlMember = new DeleteMember (con);
				desktop.add (dlMember);
				dlMember.show ();
			}

		}
		else if (obj == findBook || obj == find || obj == btnFindBook) {

			boolean b = openChildWindow ("Search Books");
			if (b == false) {
				SearchBook srBook = new SearchBook (con);
				desktop.add (srBook);
				srBook.show ();
			}

		}
		else if (obj == findMember || obj == btnFindMember) {

			boolean b = openChildWindow ("Search Members");
			if (b == false) {
				SearchMember srMember = new SearchMember (con);
				desktop.add (srMember);
				srMember.show ();
			}

		}
		else if (obj == viewAllBook) {

			boolean b = openChildWindow ("View All Books");
			if (b == false) {
				ViewAllBooks vwAllBook = new ViewAllBooks (con);
				desktop.add (vwAllBook);
				vwAllBook.show ();
			}

		}
		else if (obj == viewAllMember || obj == view) {

			boolean b = openChildWindow ("View All Members");
			if (b == false) {
				ViewAllMembers vwAllMember = new ViewAllMembers (con);
				desktop.add (vwAllMember);
				vwAllMember.show ();
			}

		}
		else if (obj == viewIssueBook) {

			boolean b = openChildWindow ("View All Issued Books");
			if (b == false) {
				ViewIssuedBooks vwIssue = new ViewIssuedBooks (con);
				desktop.add (vwIssue);
				vwIssue.show ();
			}

		}
		else if (obj == change) {

			Color cl = desktop.getBackground ();	//Getting the Current Background Color.
			//Showing the Color Dialog Box to Change Background Color.
			cl = JColorChooser.showDialog (this, "Choose Background Color", cl);
			if (cl == null) { }			//If No Color is Selected.
			else {
				desktop.setBackground (cl);	//Aplying Selected Color for Background Color.
				desktop.repaint ();		//Repaint the DesktopPane.
			}

		}
		else if (obj == changePassword || obj == btnChange) {

			boolean b = openChildWindow ("Change Password");
			if (b == false) {
				ChangePassword chPass = new ChangePassword (userName, con);
				desktop.add (chPass);
				chPass.show ();
			}
		}
		else if (obj == makeUser) {

			boolean b = openChildWindow ("Create New User");
			if (b == false) {
				NewUser mkUser = new NewUser (con);
				desktop.add (mkUser);
				mkUser.show ();
			}
		}
		else if (obj == close) {

			JInternalFrame Frames[] = desktop.getAllFrames (); 	//Getting all Open Frames.

			for (int getFrameLoop = 0; getFrameLoop < Frames.length; getFrameLoop++) {
				try {
	 				Frames[getFrameLoop].setClosed (true); 	//Close the Active Frame.
					break;					//Exit From Loop.
				} 
				catch (Exception CloseExc) { }			//if Error then Do Nothing.
			}

			/*
			//Following Lines also Work Nice If You Trying to Close the Active Form in Current Program
			//But it only Works then If You've JDK 1.3 or Higher Installed on Your System.
			try {
				desktop.getSelectedFrame().setClosed(true);	//Closing the Active Form.
			}
			catch (Exception CloseExc) { }*/

		}
		else if (obj == closeAll) {

			JInternalFrame Frames[] = desktop.getAllFrames (); 	//Getting all Open Frames.

			for (int getFrameLoop = 0; getFrameLoop < Frames.length; getFrameLoop++) {
				try {
	 				Frames[getFrameLoop].setClosed (true); 	//Close the Active Frame One By One.
				} 
				catch (Exception CloseExc) { }			//if Error then Do Nothing.
			}

		}
		else if (obj == content || obj == btnHelp) {

			//Showing Program's Help so User can Understand the Program & Work Easily in it.
			boolean b = openChildWindow ("LibrarySystem Help");
			if (b == false) {
				LibraryHelp hlpLib = new LibraryHelp ("LibrarySystem Help", "Help/Library.htm");
				desktop.add (hlpLib);
				hlpLib.show ();
			}

		}
		else if (obj == keyHelp || obj == btnKey) {

			//Showing the Shortcut Keys of Program to Guide User.
			boolean b = openChildWindow ("LibrarySystem Keys");
			if (b == false) {
				LibraryHelp hlpKey = new LibraryHelp ("LibrarySystem Keys", "Help/Keys.htm");
				desktop.add (hlpKey);
				hlpKey.show ();
			}

		}
		else if (obj == about) {

			//Showing the MessageBox Containig the Muhammad Wasif's LibrarySystem Credits.
			String msg = "Muhammad Wasif's LibrarySystem.\n\n" + "Created & Designed By:\n" + 
				"Muhammad Wasif Javed\n\n" + "E-mail me:\n wasijaved@yahoo.com";
			JOptionPane.showMessageDialog (this, msg, "About LibrarySystem", JOptionPane.PLAIN_MESSAGE);

		}

	}

	//Function Perform By LookAndFeel MenuItem (Style MenuItem).

	public void itemStateChanged (ItemEvent e) {

		for( int i = 0; i < radio.length; i++ )
			if(radio[i].isSelected()) {		//Getting Selected Look & Feel Option.
				changeLookAndFeel (i);		//Change the Program's Look & Feel.
			}

	}	

	//Function for Changing the Program's Look & Feel.

	public void changeLookAndFeel (int val) {

		try {
			UIManager.setLookAndFeel (looks[val].getClassName());	//Getting the Look & Feel Name.
			SwingUtilities.updateComponentTreeUI (this);		//Changing Look & Feel of Program.
		}
		catch (Exception e) { }

	}

	//Loop Through All the Opened JInternalFrame to Perform the Task.

	private boolean openChildWindow (String title) {

		JInternalFrame[] childs = desktop.getAllFrames ();		//Get All Open Child Windows.
		for (int i = 0; i < childs.length; i++) {
			if (childs[i].getTitle().equalsIgnoreCase (title)) {	//Getting the Title of Child Window.
				childs[i].show ();				//Setting Focus on the Child Window.
				return true;
			}
		}
		return false;

	}

	//Function For Closing the Program.

	private void quitApp () {

		try {
			//Show a Confirmation Dialog.
		    	int reply = JOptionPane.showConfirmDialog (this, 
				"Are you really want to exit From\nMuhammad Wasif's LibrarySystem?",
				"LibrarySystem - Exit", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
			//Check the User Selection.
			if (reply == JOptionPane.YES_OPTION) {				//If User's Choice Yes then.
				setVisible (false);					//Hide the Frame.
				System.out.println ("\n\nThanks For Using Muhammad " + 	//Displaying Message on Screen.
						"Wasif's LibrarySystem.\nAuthor : " + 
						"Muhammad Wasif Javed\n");
				dispose();            					//Free the System Resources.
				System.exit (0);        				//Close the Application.
			}
			else if (reply == JOptionPane.NO_OPTION) {			//If User's Choice No then.
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);	//Do Nothing Return to Program.
			}
		} 

		catch (Exception e) {}

	}

	//Following Functions use for Printing Book Record.

	void getBookId () {

		String printing;

			try {	//Getting User's Answer.
				printing = JOptionPane.showInputDialog (this, "Enter Book Id to Print Book Detail.\n" +
			"(Tip: Book Id Contains only Digits)", "LibrarySystem - PrintRecord", JOptionPane.PLAIN_MESSAGE);

				if (printing == null) { }	//If Cancelling the Printing.
				if (printing.equals ("")) {	//If No Value Provided.
					JOptionPane.showMessageDialog (this, "Provide Book Id to Print.",
					 "LibrarySystem - EmptyField", JOptionPane.PLAIN_MESSAGE);
					getBookId ();		//Calling Same Function Again.
				}
				else {
					findBookRec (printing, con);	//Finding Book Record.
				}
			}
			catch (Exception e) { }

	}

	//Function use to Find Book Record.

	void findBookRec (String rec, Connection con) {

		long id = Integer.parseInt (rec);	//Converting String to Numeric.
		long bookNo;				//Use for Comparing the Book's Id.
		boolean found = false;			//To Confirm the Book's Id Existance.

		try {	//SELECT Query to Retrieved the Record.
			String q = "SELECT * FROM Books WHERE BookId = " + id + "";

			st = con.createStatement ();		//Creating Statement Object.
			ResultSet rs = st.executeQuery (q);	//Executing the Query.
			rs.next ();				//Moving towards the Record.
			bookNo = rs.getLong ("BookId");		//Storing the Record.
			if (bookNo == id) {			//If Record Found then Display Records.
				found = true;
				String bookName = rs.getString ("BookName");
				String author = rs.getString ("BookAuthor");
				long price = rs.getLong ("BookPrice");
				String cat = rs.getString ("Category");
				//Printing the Book Record.
				printRecord (makeBookPrint ("" + id, bookName, author, "" + price, cat));
			}
		}
		catch(SQLException sqlex) {
			if (found == false) {
				JOptionPane.showMessageDialog (this, "Record not Found.");
				getBookId ();
			}
		}

	}

	//Function use to make Current Record ready for Print.

	String makeBookPrint (String id, String name, String author, String price, String category) {

		String data = "";

		String data0 = "\n               Muhammad Wasif's LibrarySystem  \n";		//Page Title.
		String data1 = "                         Book Detail             \n\n";		//Page Header.
		String data2 = "  Book ID:         " + id +		"\n";
		String data3 = "  Book Name:       " + name +		"\n";
		String data4 = "  Book Author:     " + author +		"\n";
		String data5 = "  Book Price:      " + price +		"\n";
		String data6 = "  Book Category:   " + category + 	"\n";
		String data7 = "            Copyright � 2004 Muhammad Wasif Javed.\n";		//Page Footer.
		String sep0 = " -----------------------------------------------------------\n";
		String sep1 = " -----------------------------------------------------------\n";
		String sep2 = " -----------------------------------------------------------\n";
		String sep3 = " -----------------------------------------------------------\n";
		String sep4 = " -----------------------------------------------------------\n";
		String sep5 = " -----------------------------------------------------------\n";

		data = data0 + sep0 + data1 + data2 + sep1 + data3 + sep2 + data4 + sep3 + data5 + sep4 + data6 + 
			sep5 + data7;
		return data;

	}

	//Following Functions use for Printing Member Record.

	void getMemberId () {

		String printing;

			try {
				printing = JOptionPane.showInputDialog (this, "Enter Member Id to Print Member Detail.\n" +
			"(Tip: Member Id Contains only Digits)", "LibrarySystem - PrintRecord", JOptionPane.PLAIN_MESSAGE);

				if (printing == null) { }
				if (printing.equals ("")) {
					JOptionPane.showMessageDialog (this, "Provide Member Id to Print.",
					 "LibrarySystem - EmptyField", JOptionPane.PLAIN_MESSAGE);
					getMemberId ();
				}
				else {
					findMemberRec (printing, con);	//Finding Member Record.
				}
			}
			catch (Exception e) { }

	}

	//Function use to Find Member Record.

	void findMemberRec (String rec, Connection con) {

		long id = Integer.parseInt (rec);	//Converting String to Numeric.
		long memberNo;				//Use for Comparing the Book's Id.
		boolean found = false;			//To Confirm the Book's Id Existance.

		try {	//SELECT Query to Retrieved the Record.
			String q = "SELECT * FROM Members WHERE MemberId = " + id + "";

			st = con.createStatement ();		//Creating Statement Object.
			ResultSet rs = st.executeQuery (q);	//Executing the Query.
			rs.next ();				//Moving towards the Record.
			memberNo = rs.getLong ("MemberId");	//Storing the Record.
			if (memberNo == id) {			//If Record Found then Display Records.
				found = true;
				String memberName = rs.getString ("MemberName");
				String address = rs.getString ("MemberAddress");
				String entryDate = rs.getString ("EntryDate");
				//Printing the Member Record.
				printRecord (makeMemberPrint ("" + id, memberName, address, entryDate));
			}
		}
		catch(SQLException sqlex) {
			if (found == false) {
				JOptionPane.showMessageDialog (this, "Record not Found.");
				getMemberId ();
			}
		}

	}

	//Function use to make Member Record ready for Print.

	String makeMemberPrint (String id, String name, String address, String entryDate) {

		String data = "";

		String data0 = "\n               Muhammad Wasif's LibrarySystem  \n";		//Page Title.
		String data1 = "                       Member Detail             \n\n";		//Page Header.
		String data2 = "  Member ID:         " + id +			"\n";
		String data3 = "  Member Name:       " + name +			"\n";
		String data4 = "  Member Address:    " + address +		"\n";
		String data5 = "  Member Since:      " + entryDate +		"\n";
		String data6 = "            Copyright � 2004 Muhammad Wasif Javed.\n";		//Page Footer.
		String sep0 = " -----------------------------------------------------------\n";
		String sep1 = " -----------------------------------------------------------\n";
		String sep2 = " -----------------------------------------------------------\n";
		String sep3 = " -----------------------------------------------------------\n";
		String sep4 = " -----------------------------------------------------------\n\n";

		data = data0 + sep0 + data1 + data2 + sep1 + data3 + sep2 + data4 + sep3 + data5 + sep4 + data6;
		return data;

	}

	//Following Functions use for Printing Issue Book Record.

	void getIssueBook () {

		String printing;

			try {
				printing = JOptionPane.showInputDialog (this, "Enter Book Id to Print Issue Book Detail.\n" +
			"(Tip: Book Id Contains only Digits)", "LibrarySystem - PrintRecord", JOptionPane.PLAIN_MESSAGE);

				if (printing == null) { }
				if (printing.equals ("")) {
					JOptionPane.showMessageDialog (this, "Provide Book Id to Print.",
					 "LibrarySystem - EmptyField", JOptionPane.PLAIN_MESSAGE);
					getIssueBook ();
				}
				else {
					findIssueBook (printing, con);	//Finding the Issue Book Record.
				}
			}
			catch (Exception e) { }

	}

	//Function use to Find Issue Book Record.

	void findIssueBook (String rec, Connection con) {

		long id = Integer.parseInt (rec);	//Converting String to Numeric.
		long bookNo;				//Use for Comparing the Book's Id.
		boolean found = false;			//To Confirm the Book's Id Existance.

		try {	//SELECT Query to Retrieved the Record.
			String q = "SELECT IssuedBooks.BookId, IssuedBooks.BookName, IssuedBooks.BookAuthor, " + 
				"IssuedBooks.Category, Members.MemberName FROM IssuedBooks " + 
				"INNER JOIN Members ON IssuedBooks.MemberId = Members.MemberId " + 
				"WHERE BookId = " + id + "";

			st = con.createStatement ();		//Creating Statement Object.
			ResultSet rs = st.executeQuery (q);	//Executing the Query.
			rs.next ();				//Moving towards the Record.
			bookNo = rs.getLong ("BookId");		//Storing the Record.
			if (bookNo == id) {			//If Record Found then Display Records.
				found = true;
				String bookName = rs.getString ("BookName");
				String author = rs.getString ("BookAuthor");
				String cat = rs.getString ("Category");
				String memberName = rs.getString ("MemberName");
				//Printing the Issue Book Record.
				printRecord (makeIssueBookPrint ("" + id, bookName, author, cat, memberName));
			}
		}
		catch(SQLException sqlex) {
			if (found == false) {
				JOptionPane.showMessageDialog (this, "Record not Found.");
				getIssueBook ();
			}
		}

	}

	//Function use to make Issue Book Record ready for Print.

	String makeIssueBookPrint (String id, String name, String author, String category, String member) {

		String data = "";

		String data0 = "               Muhammad Wasif's LibrarySystem  \n";		//Page Title.
		String data1 = "                      Issue Book Detail        \n\n";		//Page Header.
		String data2 = "  Book ID:         " + id +		"\n";
		String data3 = "  Book Name:       " + name +		"\n";
		String data4 = "  Book Author:     " + author +		"\n";
		String data5 = "  Book Category:   " + category +	"\n";
		String data6 = "  Book Issue To:   " + member + 	"\n";
		String data7 = "            Copyright � 2004 Muhammad Wasif Javed.\n";		//Page Footer.
		String sep0 = " -----------------------------------------------------------\n";
		String sep1 = " -----------------------------------------------------------\n";
		String sep2 = " -----------------------------------------------------------\n";
		String sep3 = " -----------------------------------------------------------\n";
		String sep4 = " -----------------------------------------------------------\n";
		String sep5 = " -----------------------------------------------------------\n";

		data = data0 + sep0 + data1 + data2 + sep1 + data3 + sep2 + data4 + sep3 + data5 + sep4 + data6 + 
			sep5 + data7;
		return data;

	}

	//Function use to Print the Record.

	void printRecord (String rec) {

		StringReader sr = new StringReader (rec);
		LineNumberReader lnr = new LineNumberReader (sr);
		Font typeface = new Font ("Times New Roman", Font.PLAIN, 12);
		Properties p = new Properties ();
		PrintJob pJob = getToolkit().getPrintJob (this, "Print Customer Balance Report", p);

		if (pJob != null) {
			Graphics gr = pJob.getGraphics ();
			if (gr != null) {
				FontMetrics fm = gr.getFontMetrics (typeface);
				int margin = 20;
				int pageHeight = pJob.getPageDimension().height - margin;
    				int fontHeight = fm.getHeight();
	    			int fontDescent = fm.getDescent();
    				int curHeight = margin;
				String nextLine;
				gr.setFont (typeface);

				try {
					do {
						nextLine = lnr.readLine ();
						if (nextLine != null) {         
							if ((curHeight + fontHeight) > pageHeight) {	//New Page.
								gr.dispose();
								gr = pJob.getGraphics ();
								curHeight = margin;
							}							
							curHeight += fontHeight;
							if (gr != null) {
								gr.setFont (typeface);
								gr.drawString (nextLine, margin, curHeight - fontDescent);
							}
						}
					}
					while (nextLine != null);					
				}
				catch (EOFException eof) { }
				catch (Throwable t) { }
			}
			gr.dispose();
		}
		if (pJob != null)
			pJob.end ();
	}

}