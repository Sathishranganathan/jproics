-----------------------------------
Release Notes

Muhammad Wasif's LibrarySystem.
-----------------------------------

 � 2004 Muhammad Wasif Javed
	  
--------
Overview
--------

This Program handles the Low level Library System. Simply Add Books
add Members, Issue Books to Members etc. It is very easy to use as
it is totaly GUI [Graphical User Interface] based application.

-------------------
System Requirements
-------------------

To Use Muhammad Wasif's Library System You must Need The Following

1 :- Pentium I OR Higher (Pentium III for Best Results).
2 :- Atleast Java Development Kit 1.2 [1.4 Recommended]
3 :- Any Operating System (MS WINDOWS 98 Recommended because I use
	it myself & found no Error while running Program on it).
4 :- 32MB Ram (128MB for Best Results).
5 :- VJA (A Good Company VGA So Programs Interface Show Nicely).

--------------
How To Run
--------------

First of all Create DSN (Data Source Name) of the Database File included
with it name "Library.mdb" as Following.

DataSource name: Library
Database type: Microsoft Access
Database Name: Library.mdb

It is easy to Run LibrarySystem. Just set path of your Java Folder
in Dos Prompt and then type "Java Splash" and press Enter Key.
(I've made this Program on MSWindows 98 and it works very nicely on
it). If You Face any Problem Then Contact me.

It is Password Protected Program & On Logon Screen you can Provide
one of the Following Username & Password to Logon to LibrarySystem.

Username	:	Password

Admin			admin
Muhammad Wasif		wasijaved
guest			guest

If you login with "Admin" then you've all the Control on Program
otherwise you face some restrictions while using the Program.

-------
Caution
-------

Because of MSACCESS Database Java ResultSet Object must be default
READ ONLY so because of it I've following Problems in it.
While Deleting Books or Members of LibrarySystem it doesn't check
that is this Book is Issued to someone or the Member have Books under
his Belt. Other Problem is you can Issue a Already Issued Book to another
Member.
If anyone of you have some Idea to solve this Plz give it to me to make it
good one.

--------------
Contact Author
--------------

For Any Kind of Help E-mail me.

wasijaved@yahoo.com